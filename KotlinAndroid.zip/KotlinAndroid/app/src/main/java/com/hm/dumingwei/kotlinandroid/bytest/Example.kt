package com.hm.dumingwei.kotlinandroid.bytest

/**
 * Created by p_dmweidu on 2023/6/28
 * Desc: 测试，被委托的类
 */
class Example {

    var p: String by Delegate()
    var p2: String by Delegate2()

}