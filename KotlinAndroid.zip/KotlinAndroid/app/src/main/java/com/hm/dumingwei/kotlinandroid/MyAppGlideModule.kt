package com.hm.dumingwei.kotlinandroid

import com.bumptech.glide.annotation.GlideModule
import com.bumptech.glide.module.AppGlideModule

/**
 * Created by dmw on 2019/1/7.
 * Desc:
 */
@GlideModule
class MyAppGlideModule : AppGlideModule()
