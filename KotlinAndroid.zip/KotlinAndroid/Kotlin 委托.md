Kotlin 委托

参考链接：

* [Kotlin by属性委托](https://blog.csdn.net/zhaoyanjun6/article/details/119939781)