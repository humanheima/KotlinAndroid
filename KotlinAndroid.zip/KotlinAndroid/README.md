# Kotlin关于Android的都以这个项目为准

### Kotlin 相对于 Java 的优势

1. DataClass ,利用lambda 表达式可以大量减少样板代码。方法的默认参数，减少方法重载，精简代码。
2. 安全调用和Elvis表达式，减少空指针的发生概率。
3. String的拼接，集合等操作可见简洁。